#include <stdio.h>

char b[9] = {'1','2','3','4','5','6','7','8','9'}, p = 'X';

int w() {
return (b[0]==b[1]&&b[1]==b[2]) || (b[3]==b[4]&&b[4]==b[5]) ||
(b[6]==b[7]&&b[7]==b[8]) || (b[0]==b[3]&&b[3]==b[6]) ||
(b[1]==b[4]&&b[4]==b[7]) || (b[2]==b[5]&&b[5]==b[8]) ||
(b[0]==b[4]&&b[4]==b[8]) || (b[2]==b[4]&&b[4]==b[6]);
}

void d() {
printf("\n %c | %c | %c\n---+---+---\n %c | %c | %c\n---+---+---\n %c | %c | %c\n",
b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8]);
}

int main() {
int m, c = 0;
d();

while(c < 9) {
printf("Jogador %c, digite a posicao: ", p);
scanf("%d", &m);

if(m > 0 && m < 10 && b[m-1] != p && b[m-1] != 'O') {
b[m-1] = p;
d();

if(w()) {
printf("Jogador %c venceu!\n", p);
return 0;
}

p = p == 'X' ? 'O' : 'X';
c++;
} else {
printf("Posicao invalida!\n");
}
}

printf("Empate!\n");
return 0;
}
